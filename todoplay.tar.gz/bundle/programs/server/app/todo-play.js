(function(){Goals = new Meteor.Collection("goals");
Habits = new Meteor.Collection("habits");
Dailies = new Meteor.Collection("dailies");
Todos = new Meteor.Collection("todos");

//user config stuff
Config = new Meteor.Collection("config"); 

})();
