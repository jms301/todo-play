(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Autoupdate = Package.autoupdate.Autoupdate;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['standard-app-packages'] = {};

})();

//# sourceMappingURL=standard-app-packages.js.map
