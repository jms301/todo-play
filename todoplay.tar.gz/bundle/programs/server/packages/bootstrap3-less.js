(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['bootstrap3-less'] = {};

})();

//# sourceMappingURL=bootstrap3-less.js.map
